<?php
/**
 * Plugin Name:  Classifieds WP
 * Plugin URI:   http://classifiedswp.com/
 * Description:  A simple, clean and intuitive classifieds plugin. Manage classified listings from the WordPress admin panel, and allow users to post classifieds directly to your site.
 * Version:      1.2
 * Author:       classifiedswp
 * Author URI:   http://classifiedswp.com
 * Tested up to: 4.5
 * Text Domain:  classifieds-wp
 * Requires at least: 4.1
 * Domain Path: /languages/
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WP_Classified_Manager class.
 */
class WP_Classified_Manager {

	/**
	 * Constructor - get the plugin hooked in and ready
	 */
	public function __construct() {
		// Define constants
		define( 'WP_CLASSIFIED_MANAGER_VERSION', '1.2' );
		define( 'WP_CLASSIFIED_MANAGER_PLUGIN_DIR', untrailingslashit( plugin_dir_path( __FILE__ ) ) );
		define( 'WP_CLASSIFIED_MANAGER_PLUGIN_URL', untrailingslashit( plugins_url( basename( plugin_dir_path( __FILE__ ) ), basename( __FILE__ ) ) ) );

		// Includes
		include( 'includes/class-wp-classified-manager-install.php' );
		include( 'includes/class-wp-classified-manager-post-types.php' );
		include( 'includes/class-wp-classified-manager-ajax.php' );
		include( 'includes/class-wp-classified-manager-shortcodes.php' );
		include( 'includes/class-wp-classified-manager-api.php' );
		include( 'includes/class-wp-classified-manager-forms.php' );
		include( 'includes/class-wp-classified-manager-geocode.php' );
		include( 'includes/class-wp-classified-manager-cache-helper.php' );

		// Use WP native media viewer in frontend.
		if ( apply_filters( 'classified_manager_enable_media_viewer', true ) ) {
			include( 'includes/class-wp-classified-manager-media-viewer.php' );
		}

		if ( is_admin() ) {
			include( 'includes/admin/class-wp-classified-manager-admin.php' );
			include( 'includes/admin/licenses-manager/load.php' );
		}

		// Init classes
		$this->forms      = new WP_Classified_Manager_Forms();
		$this->post_types = new WP_Classified_Manager_Post_Types();

		// Activation - works with symlinks
		register_activation_hook( basename( dirname( __FILE__ ) ) . '/' . basename( __FILE__ ), array( $this, 'activate' ) );

		// Switch theme
		add_action( 'after_switch_theme', array( 'WP_Classified_Manager_Ajax', 'add_endpoint' ), 10 );
		add_action( 'after_switch_theme', array( $this->post_types, 'register_post_types' ), 11 );
		add_action( 'after_switch_theme', 'flush_rewrite_rules', 15 );

		// Actions
		add_action( 'after_setup_theme', array( $this, 'load_plugin_textdomain' ) );
		add_action( 'after_setup_theme', array( $this, 'include_template_functions' ), 11 );
		add_action( 'after_setup_theme', array( $this, 'add_theme_support' ), 20 );
		add_action( 'widgets_init', array( $this, 'widgets_init' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'frontend_scripts' ) );
		add_action( 'admin_init', array( $this, 'updater' ) );
	}

	/**
	 * Called on plugin activation
	 */
	public function activate() {
		WP_Classified_Manager_Ajax::add_endpoint();
		$this->post_types->register_post_types();
		WP_Classified_Manager_Install::install();
		flush_rewrite_rules();
	}

	/**
	 * Handle Updates
	 */
	public function updater() {
		if ( version_compare( WP_CLASSIFIED_MANAGER_VERSION, get_option( 'wp_classified_manager_version' ), '>' ) ) {
			WP_Classified_Manager_Install::install();
			flush_rewrite_rules();
		}
	}

	/**
	 * Localization.
	 */
	public function load_plugin_textdomain() {
		load_textdomain( 'classifieds-wp', WP_LANG_DIR . "/classifieds-wp/classifieds-wp-" . apply_filters( 'plugin_locale', get_locale(), 'classifieds-wp' ) . ".mo" );
		load_plugin_textdomain( 'classifieds-wp', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

		// Loads the old text domain to the list of domains.
		$this->load_old_plugin_textdomain();
	}

	/**
	 * Provide support for the older text domain.
	 */
	public function load_old_plugin_textdomain() {
		load_textdomain( 'classifieds-wp', WP_LANG_DIR . "/wp-classified-manager/wp-classified-manager-" . apply_filters( 'plugin_locale', get_locale(), 'wp-classified-manager' ) . ".mo" );
		load_plugin_textdomain( 'classifieds-wp', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
	}

	/**
	 * Load functions
	 */
	public function include_template_functions() {
		include( 'wp-classified-manager-functions.php' );
		include( 'wp-classified-manager-template.php' );
	}

	/**
	 * Add theme support features.
	 *
	 * @since 1.2
	 */
	public function add_theme_support() {
		global $_wp_theme_features;

		// Add support for 'post-thumbnails'.
		if ( ! current_theme_supports( 'post-thumbnails', 'classified_listing' ) ) {

			if ( ! current_theme_supports( 'post-thumbnails' ) ) {
				add_theme_support( 'post-thumbnails', array( 'classified_listing' )  );
			} elseif ( ! empty( $_wp_theme_features['post-thumbnails'][0] ) ) {
				$_wp_theme_features['post-thumbnails'][0][] = 'classified_listing';
			}

		}

	}

	/**
	 * Widgets init.
	 */
	public function widgets_init() {
		include_once( 'includes/class-wp-classified-manager-widgets.php' );
	}

	/**
	 * Register and enqueue scripts and css
	 */
	public function frontend_scripts() {
		$ajax_url         = WP_Classified_Manager_Ajax::get_endpoint();
		$ajax_filter_deps = array( 'jquery', 'jquery-deserialize' );

		$ext = ( ! defined('SCRIPT_DEBUG') || ! SCRIPT_DEBUG ? '.min' : '' )  . '.js';

		if ( apply_filters( 'classified_manager_chosen_enabled', true ) ) {
			wp_register_script( 'chosen', WP_CLASSIFIED_MANAGER_PLUGIN_URL . '/assets/js/jquery-chosen/chosen.jquery.min.js', array( 'jquery' ), '1.1.0', true );
			wp_register_script( 'wp-classified-manager-term-multiselect', WP_CLASSIFIED_MANAGER_PLUGIN_URL . '/assets/js/term-multiselect' . $ext, array( 'jquery', 'chosen' ), WP_CLASSIFIED_MANAGER_VERSION, true );
			wp_register_script( 'wp-classified-manager-multiselect', WP_CLASSIFIED_MANAGER_PLUGIN_URL . '/assets/js/multiselect.min.js', array( 'jquery', 'chosen' ), WP_CLASSIFIED_MANAGER_VERSION, true );
			wp_enqueue_style( 'chosen', WP_CLASSIFIED_MANAGER_PLUGIN_URL . '/assets/css/chosen.css' );
			$ajax_filter_deps[] = 'chosen';

			wp_localize_script( 'chosen', 'classified_manager_chosen_multiselect_args',
				apply_filters( 'classified_manager_chosen_multiselect_args', array( 'search_contains' => true ) )
			);
		}

		if ( apply_filters( 'classified_manager_ajax_file_upload_enabled', true ) ) {
			wp_register_script( 'jquery-iframe-transport', WP_CLASSIFIED_MANAGER_PLUGIN_URL . '/assets/js/jquery-fileupload/jquery.iframe-transport.js', array( 'jquery' ), '1.8.3', true );
			wp_register_script( 'jquery-fileupload', WP_CLASSIFIED_MANAGER_PLUGIN_URL . '/assets/js/jquery-fileupload/jquery.fileupload.js', array( 'jquery', 'jquery-iframe-transport', 'jquery-ui-widget' ), '9.11.2', true );
			wp_register_script( 'wp-classified-manager-ajax-file-upload', WP_CLASSIFIED_MANAGER_PLUGIN_URL . '/assets/js/ajax-file-upload' . $ext, array( 'jquery', 'jquery-fileupload' ), WP_CLASSIFIED_MANAGER_VERSION, true );

			ob_start();
			get_classified_manager_template( 'form-fields/uploaded-file-html.php', array( 'name' => '', 'value' => '', 'extension' => 'jpg' ) );
			$js_field_html_img = ob_get_clean();

			ob_start();
			get_classified_manager_template( 'form-fields/uploaded-file-html.php', array( 'name' => '', 'value' => '', 'extension' => 'zip' ) );
			$js_field_html = ob_get_clean();

			$size = (int) get_option( 'classified_manager_max_image_size' );

			wp_localize_script( 'wp-classified-manager-ajax-file-upload', 'classified_manager_ajax_file_upload', array(
				'ajax_url'                => $ajax_url,
				'js_field_html_img'       => esc_js( str_replace( "\n", "", $js_field_html_img ) ),
				'js_field_html'           => esc_js( str_replace( "\n", "", $js_field_html ) ),
				'i18n_invalid_file_type'  => __( 'Invalid file type. Accepted types:', 'classifieds-wp' ),
				'i18n_file_size_exceeded' => sprintf( __( 'File size exceeds maximum allowed size of %s.', 'classifieds-wp' ), size_format( $size * 1024 ) ),
				'max_file_size'           => $size * 1024,
			) );
		}

		if ( apply_filters( 'classified_manager_validate_enabled', true ) ) {
			wp_register_script( 'jquery-validate', WP_CLASSIFIED_MANAGER_PLUGIN_URL . '/assets/js/jquery-validate/jquery.validate.min.js', array( 'jquery' ), '1.15.0', true );

			$locale = apply_filters( 'plugin_locale', get_locale(), 'classifieds-wp' );
			$file   = 'messages_' . $locale . '.min.js';

			/**
			 * Look for the jQuery validate localization files.
			 *
			 * Place your jQuery validate locale file under '.../wp-content/languages/classifieds-wp/jquery-validate/'.
			 */
			$language_dir = WP_LANG_DIR . '/classifieds-wp/jquery-validate/' . $file;
			$language_url = content_url() . '/languages/classifieds-wp/jquery-validate/' . $file;

			/**
			 * Hook into 'classified_manager_jquery_validate_lang' to override the default language folder.
			 */
			$language_url = apply_filters( 'classified_manager_jquery_validate_lang', $language_url, $locale );

			if ( file_exists( $language_dir ) ) {
				wp_register_script( 'jquery-validate-locale', $language_url, array( 'jquery-validate' ), '1.15.0', true );
			} else {

				// Backwards compat - check in old folder name.
				$language_dir = WP_LANG_DIR . '/wp-classified-manager/jquery-validate/' . $file;
				$language_url = content_url() . '/languages/wp-classified-manager/jquery-validate/' . $file;

				$language_url = apply_filters( 'classified_manager_jquery_validate_lang', $language_url, $locale );

				if ( file_exists( $language_dir ) ) {
					wp_register_script( 'jquery-validate-locale', $language_url, array( 'jquery-validate' ), '1.15.0', true );
				}

			}

		}

		wp_register_script( 'jquery-deserialize', WP_CLASSIFIED_MANAGER_PLUGIN_URL . '/assets/js/jquery-deserialize/jquery.deserialize.js', array( 'jquery' ), '1.2.1', true );
		wp_register_script( 'wp-classified-manager-ajax-filters', WP_CLASSIFIED_MANAGER_PLUGIN_URL . '/assets/js/ajax-filters' . $ext, $ajax_filter_deps, WP_CLASSIFIED_MANAGER_VERSION, true );
		wp_register_script( 'wp-classified-manager-classified-dashboard', WP_CLASSIFIED_MANAGER_PLUGIN_URL . '/assets/js/classified-dashboard' . $ext, array( 'jquery' ), WP_CLASSIFIED_MANAGER_VERSION, true );
		wp_register_script( 'wp-classified-manager-classified-contact', WP_CLASSIFIED_MANAGER_PLUGIN_URL . '/assets/js/classified-contact' . $ext, array( 'jquery' ), WP_CLASSIFIED_MANAGER_VERSION, true );
		wp_register_script( 'wp-classified-manager-classified-submission', WP_CLASSIFIED_MANAGER_PLUGIN_URL . '/assets/js/classified-submission' . $ext, array( 'jquery' ), WP_CLASSIFIED_MANAGER_VERSION, true );

		wp_localize_script( 'wp-classified-manager-classified-submission', 'wpcm_i18n', array(
			'images_required' => get_option('classified_manager_require_images'),
		) );

		wp_localize_script( 'wp-classified-manager-ajax-filters', 'classified_manager_ajax_filters', array(
			'ajax_url'                => $ajax_url,
			'is_rtl'                  => is_rtl() ? 1 : 0,
			'lang'                    => defined( 'ICL_LANGUAGE_CODE' ) ? ICL_LANGUAGE_CODE : '', // WPML workaround until this is standardized
			'i18n_load_prev_listings' => __( 'Load previous listings', 'classifieds-wp' )
		) );
		wp_localize_script( 'wp-classified-manager-classified-dashboard', 'classified_manager_classified_dashboard', array(
			'i18n_confirm_delete' => __( 'Are you sure you want to delete this listing?', 'classifieds-wp' )
		) );

		wp_enqueue_style( 'wp-classified-manager-frontend', WP_CLASSIFIED_MANAGER_PLUGIN_URL . '/assets/css/frontend.css' );
	}
}

$GLOBALS['classified_manager'] = new WP_Classified_Manager();
