# Classifieds WP

A simple, clean and extensive classifieds plugin.
