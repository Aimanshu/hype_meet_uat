<?php if ( is_active_sidebar( 'classified-manager-sidebar-single' )  ) : ?>

	<aside id="classified-manager-single-sidebar-secondary" class="sidebar classified-manager-single-sidebar widget-area" role="complementary">
		<?php dynamic_sidebar('classified-manager-sidebar-single'); ?>
	</aside><!-- .sidebar .widget-area -->

<?php endif; ?>