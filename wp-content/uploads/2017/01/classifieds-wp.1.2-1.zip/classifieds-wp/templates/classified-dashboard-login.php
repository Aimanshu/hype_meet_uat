<div id="classified-manager-classified-dashboard">

	<p class="account-sign-in"><?php _e( 'You need to be signed in to manage your listings.', 'classifieds-wp' ); ?> <a class="button" href="<?php echo apply_filters( 'classified_manager_classified_dashboard_login_url', wp_login_url( get_permalink() ) ); ?>"><?php _e( 'Sign in', 'classifieds-wp' ); ?></a></p>

</div>