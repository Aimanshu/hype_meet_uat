jQuery(document).ready(function($) {

	$('.classified-dashboard-action-delete').click(function() {
		return confirm( classified_manager_classified_dashboard.i18n_confirm_delete );
	});

});