jQuery(function(){
	jQuery( '.classified-manager-category-dropdown' ).chosen( classified_manager_chosen_multiselect_args );
});
