jQuery(function(){
	jQuery( '.classified-manager-multiselect' ).chosen( classified_manager_chosen_multiselect_args );
});
